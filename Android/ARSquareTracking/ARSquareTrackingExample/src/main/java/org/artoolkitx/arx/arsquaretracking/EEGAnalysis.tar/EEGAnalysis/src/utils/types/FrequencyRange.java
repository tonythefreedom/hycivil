package org.artoolkitx.arx.arsquaretracking.EEGAnalysis.src.utils.types;

public class FrequencyRange extends Range<Double> {
	public FrequencyRange() {
		
	}
	public FrequencyRange(double lower, double higher) {
		this.lower = lower;
		this.higher = higher;
	}
}
