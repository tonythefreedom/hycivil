package org.artoolkitx.arx.arsquaretracking.EEGAnalysis.src.utils.types;

public class AmplitudeRange extends Range<Integer> {
	public AmplitudeRange() {}
	public AmplitudeRange(int lower, int higher) {
		this.lower = lower;
		this.higher = higher;
	}
}
